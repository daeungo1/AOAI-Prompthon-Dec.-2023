# MTC Prompton Hands-on Workshop

/2023 Nov. Edition/

#### 진행 순서

| 시간표                                                       |
| ------------------------------------------------------------ |
| (0.5h)  개발 환경 세팅 및 실습 소개   - GitHub Codespace 기반<br />(1.5h)  코드 기반 프롬프트 엔지니어링 실습  <br />(0.5h)  RAG 기반 나만의 챗봇 서비스 만들기  <br />(0.5h)  Function Calling 활용 방법  <br />(0.5h)  STT/OpenAI/TTS를 활용한 나만의 Jarvis 비서 만들기   <br />(0.5h)  Q&A |



#### 함께 참여하는 Workshop 진행을 위해 웹연결을 통해 Communication을 진행합니다. 

#### **2가지 연결 방법**

1. Link 로 연결 - https://www.menti.com/als2y9euu4ea

2. 웹주소/QR Code 및 Code 입력으로 연결

   ![menti](./images/menti.png)

   
